#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/app_source/android"
chmod +x gradlew
./gradlew :app:assembleFossDebug --no-daemon --stacktrace
APK=app/build/outputs/apk/foss/debug/app-foss-debug.apk
test -s "$APK"
printf '\nAPK: %s\n' "$APK"
sha256sum "$APK"
